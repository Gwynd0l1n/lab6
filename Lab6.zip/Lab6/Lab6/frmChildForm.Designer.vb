﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmChildForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tblTextBox = New System.Windows.Forms.RichTextBox()
        Me.ttChild = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'tblTextBox
        '
        Me.tblTextBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tblTextBox.Location = New System.Drawing.Point(0, 0)
        Me.tblTextBox.Margin = New System.Windows.Forms.Padding(2)
        Me.tblTextBox.Name = "tblTextBox"
        Me.tblTextBox.Size = New System.Drawing.Size(800, 450)
        Me.tblTextBox.TabIndex = 1
        Me.tblTextBox.Text = ""
        '
        'frmChildForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.tblTextBox)
        Me.Name = "frmChildForm"
        Me.Text = "ChildForm"
        Me.ttChild.SetToolTip(Me, "This is the child form where you will be typing :)")
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tblTextBox As RichTextBox
    Friend WithEvents ttChild As ToolTip
End Class
