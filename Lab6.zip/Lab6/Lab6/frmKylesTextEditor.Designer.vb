﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKylesTextEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKylesTextEditor))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ftsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ntsMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.otsStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.stsMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.satsMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctsMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.etsMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.etsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsWindows = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileHorizontallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TileVerticallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CascadeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AverageUnitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblStatusStrip = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ttTextEditor = New System.Windows.Forms.ToolTip(Me.components)
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SaveButton1 = New System.Windows.Forms.ToolStripButton()
        Me.NewButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.lblStatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator1, Me.SaveButton1, Me.NewButton1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(800, 27)
        Me.ToolStrip1.TabIndex = 7
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ftsMenuItem, Me.etsMenuItem, Me.tsWindows, Me.tsHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.MdiWindowListItem = Me.tsWindows
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ftsMenuItem
        '
        Me.ftsMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ntsMenuItem1, Me.otsStripMenuItem1, Me.stsMenuItem1, Me.satsMenuItem1, Me.ctsMenuItem1, Me.etsMenuItem1})
        Me.ftsMenuItem.Name = "ftsMenuItem"
        Me.ftsMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.ftsMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ftsMenuItem.Text = "File"
        '
        'ntsMenuItem1
        '
        Me.ntsMenuItem1.Name = "ntsMenuItem1"
        Me.ntsMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.ntsMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.ntsMenuItem1.Text = "&New"
        '
        'otsStripMenuItem1
        '
        Me.otsStripMenuItem1.Name = "otsStripMenuItem1"
        Me.otsStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.otsStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.otsStripMenuItem1.Text = "&Open"
        '
        'stsMenuItem1
        '
        Me.stsMenuItem1.Name = "stsMenuItem1"
        Me.stsMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.stsMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.stsMenuItem1.Text = "&Save"
        '
        'satsMenuItem1
        '
        Me.satsMenuItem1.Name = "satsMenuItem1"
        Me.satsMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.satsMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.satsMenuItem1.Text = "Save As"
        '
        'ctsMenuItem1
        '
        Me.ctsMenuItem1.Name = "ctsMenuItem1"
        Me.ctsMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.ctsMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.ctsMenuItem1.Text = "Close"
        '
        'etsMenuItem1
        '
        Me.etsMenuItem1.Name = "etsMenuItem1"
        Me.etsMenuItem1.ShortcutKeyDisplayString = ""
        Me.etsMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.etsMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.etsMenuItem1.Text = "Exit"
        '
        'etsMenuItem
        '
        Me.etsMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CutToolStripMenuItem1, Me.CopyToolStripMenuItem1, Me.PasteToolStripMenuItem1})
        Me.etsMenuItem.Name = "etsMenuItem"
        Me.etsMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.etsMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.etsMenuItem.Text = "Edit"
        '
        'CutToolStripMenuItem1
        '
        Me.CutToolStripMenuItem1.Name = "CutToolStripMenuItem1"
        Me.CutToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.CutToolStripMenuItem1.Text = "Cu&t "
        '
        'CopyToolStripMenuItem1
        '
        Me.CopyToolStripMenuItem1.Name = "CopyToolStripMenuItem1"
        Me.CopyToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.CopyToolStripMenuItem1.Text = "&Copy"
        '
        'PasteToolStripMenuItem1
        '
        Me.PasteToolStripMenuItem1.Name = "PasteToolStripMenuItem1"
        Me.PasteToolStripMenuItem1.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.PasteToolStripMenuItem1.Text = "Paste"
        '
        'tsWindows
        '
        Me.tsWindows.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TileHorizontallyToolStripMenuItem, Me.TileVerticallyToolStripMenuItem, Me.CascadeToolStripMenuItem, Me.ToolStripMenuItem2, Me.AverageUnitsToolStripMenuItem})
        Me.tsWindows.Name = "tsWindows"
        Me.tsWindows.Size = New System.Drawing.Size(68, 20)
        Me.tsWindows.Text = "&Windows"
        Me.tsWindows.ToolTipText = "Options For Open Windows"
        '
        'TileHorizontallyToolStripMenuItem
        '
        Me.TileHorizontallyToolStripMenuItem.Name = "TileHorizontallyToolStripMenuItem"
        Me.TileHorizontallyToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TileHorizontallyToolStripMenuItem.Text = "Tile &Horizontally"
        Me.TileHorizontallyToolStripMenuItem.ToolTipText = "Lay Tiles Horizontally"
        '
        'TileVerticallyToolStripMenuItem
        '
        Me.TileVerticallyToolStripMenuItem.Name = "TileVerticallyToolStripMenuItem"
        Me.TileVerticallyToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TileVerticallyToolStripMenuItem.Text = "Tile &Vertically"
        Me.TileVerticallyToolStripMenuItem.ToolTipText = "Lay Tiles Vertically"
        '
        'CascadeToolStripMenuItem
        '
        Me.CascadeToolStripMenuItem.Name = "CascadeToolStripMenuItem"
        Me.CascadeToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CascadeToolStripMenuItem.Text = "&Cascade"
        Me.CascadeToolStripMenuItem.ToolTipText = "Cascade the Tiles"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(177, 6)
        '
        'AverageUnitsToolStripMenuItem
        '
        Me.AverageUnitsToolStripMenuItem.Name = "AverageUnitsToolStripMenuItem"
        Me.AverageUnitsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AverageUnitsToolStripMenuItem.Text = "Average Units"
        '
        'tsHelp
        '
        Me.tsHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutProgramToolStripMenuItem})
        Me.tsHelp.Name = "tsHelp"
        Me.tsHelp.Size = New System.Drawing.Size(44, 20)
        Me.tsHelp.Text = "&Help"
        Me.tsHelp.ToolTipText = "Help With Program"
        '
        'AboutProgramToolStripMenuItem
        '
        Me.AboutProgramToolStripMenuItem.Name = "AboutProgramToolStripMenuItem"
        Me.AboutProgramToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutProgramToolStripMenuItem.Text = "&About"
        Me.AboutProgramToolStripMenuItem.ToolTipText = "About The Program"
        '
        'lblStatusStrip
        '
        Me.lblStatusStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.lblStatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.lblStatusStrip.Location = New System.Drawing.Point(0, 428)
        Me.lblStatusStrip.Name = "lblStatusStrip"
        Me.lblStatusStrip.Padding = New System.Windows.Forms.Padding(1, 0, 10, 0)
        Me.lblStatusStrip.Size = New System.Drawing.Size(800, 22)
        Me.lblStatusStrip.TabIndex = 8
        Me.lblStatusStrip.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(120, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'SaveButton1
        '
        Me.SaveButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveButton1.Image = CType(resources.GetObject("SaveButton1.Image"), System.Drawing.Image)
        Me.SaveButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveButton1.Name = "SaveButton1"
        Me.SaveButton1.Size = New System.Drawing.Size(24, 24)
        Me.SaveButton1.Text = "ToolStripButton1"
        '
        'NewButton1
        '
        Me.NewButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewButton1.Image = CType(resources.GetObject("NewButton1.Image"), System.Drawing.Image)
        Me.NewButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewButton1.Name = "NewButton1"
        Me.NewButton1.Size = New System.Drawing.Size(24, 24)
        Me.NewButton1.Text = "ToolStripButton2"
        '
        'frmKylesTextEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.lblStatusStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "frmKylesTextEditor"
        Me.Text = "Kyle's Awesome Text Editor"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.lblStatusStrip.ResumeLayout(False)
        Me.lblStatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents tsWindows As ToolStripMenuItem
    Friend WithEvents TileHorizontallyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TileVerticallyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CascadeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripSeparator
    Friend WithEvents tsHelp As ToolStripMenuItem
    Friend WithEvents AboutProgramToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblStatusStrip As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents ttTextEditor As ToolTip
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents ftsMenuItem As ToolStripMenuItem
    Friend WithEvents ntsMenuItem1 As ToolStripMenuItem
    Friend WithEvents otsStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents stsMenuItem1 As ToolStripMenuItem
    Friend WithEvents satsMenuItem1 As ToolStripMenuItem
    Friend WithEvents ctsMenuItem1 As ToolStripMenuItem
    Friend WithEvents etsMenuItem1 As ToolStripMenuItem
    Friend WithEvents etsMenuItem As ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AverageUnitsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveButton1 As ToolStripButton
    Friend WithEvents NewButton1 As ToolStripButton
End Class
