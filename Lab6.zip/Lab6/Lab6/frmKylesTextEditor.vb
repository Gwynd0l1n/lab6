﻿Option Strict On
Imports System.IO
Public Class frmKylesTextEditor
    Private docNumberInteger As Integer = 0
#Region "Windows"
    Private Sub TileHorizontallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TileHorizontallyToolStripMenuItem.Click
        LayoutMdi(MdiLayout.TileHorizontal)
    End Sub
    Private Sub TileVerticallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TileVerticallyToolStripMenuItem.Click
        LayoutMdi(MdiLayout.TileVertical)
    End Sub
    Private Sub CascadeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CascadeToolStripMenuItem.Click
        LayoutMdi(MdiLayout.Cascade)
    End Sub
#End Region
#Region "About"
    Private Sub AboutProgramToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutProgramToolStripMenuItem.Click
        MsgBox("Author: Pentakill Lee Sin Mid(Kyle Edwards)" + vbCrLf + "Class: NETD2202" + vbCrLf + "Lab6", MsgBoxStyle.OkOnly, "About")
    End Sub
#End Region
#Region "File"

    Private Sub ntsMenuItem1_Click(sender As Object, e As EventArgs) Handles ntsMenuItem1.Click
        Dim result As Integer = MessageBox.Show("Have You Saved Your Document?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            frmChildForm.tblTextBox.Clear()
            MessageBox.Show("New Document Created")
            Dim docform As New frmChildForm()
            docform.MdiParent = Me
            docNumberInteger = docNumberInteger + 1
            docform.Text = "New Document " & docNumberInteger
            docform.Show()
        ElseIf CBool(DialogResult.No) Then
            MessageBox.Show("Please Save Document")
        End If
    End Sub

    Private Sub etsMenuItem1_Click(sender As Object, e As EventArgs) Handles etsMenuItem1.Click
        Application.Exit()
    End Sub
    Private Sub stsMenuItem1_Click(sender As Object, e As EventArgs) Handles stsMenuItem1.Click
        Dim myfile As String
        Dim saveFileDialog1 As New SaveFileDialog()
        myfile = ActiveMdiChild.Text
        saveFileDialog1.OverwritePrompt = True
        saveFileDialog1.FileName = myfile
        saveFileDialog1.Filter = "Rich Text Format (*.rtf)|*.rtf|All files (*.*)|*.*"
        saveFileDialog1.ShowDialog()
        If saveFileDialog1.FileName = "" Then
            Exit Sub
        End If
    End Sub

    Private Sub otsMenuItem1_Click(sender As Object, e As EventArgs) Handles otsStripMenuItem1.Click
        Dim docform As New frmChildForm()
        docform.MdiParent = Me
        docNumberInteger = docNumberInteger + 1
        docform.Text = "New Document " & docNumberInteger
        docform.Show()
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            docform.MdiParent = Me
            Try
                Dim stream As New StreamReader(OpenFileDialog1.FileName)
                docform.tblTextBox.Text = stream.ReadToEnd
                stream.Close()
                lblStatusStrip.Text = "Open File" + OpenFileDialog1.FileName
                docform.Show()
            Catch ex As Exception
                Throw New ApplicationException(ex.ToString())
            End Try
        End If
    End Sub

    Private Sub satsMenuItem1_Click(sender As Object, e As EventArgs) Handles satsMenuItem1.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                Dim activeForm As frmChildForm = DirectCast(Me.ActiveMdiChild, frmChildForm)

                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, activeForm.tblTextBox.Text, False)
            Catch ex As Exception
                MessageBox.Show("No File To Save Exist", "Error!", MessageBoxButtons.OK,
                           MessageBoxIcon.Error)
            End Try
        End If

    End Sub
    Private Sub ctsMenuItem1_Click(sender As Object, e As EventArgs) Handles ctsMenuItem1.Click
        If (Me.MdiChildren.Length > 0) Then
            Dim activeForm As frmChildForm = DirectCast(Me.ActiveMdiChild, frmChildForm)
            activeForm.Close()
            lblStatusStrip.Text = "Form" + OpenFileDialog1.FileName + " Is Closed"
        End If
    End Sub
#End Region
#Region "Edit"
    Private Sub CutToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem1.Click
        frmChildForm.tblTextBox.Cut()
    End Sub

    Private Sub PasteToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem1.Click
        frmChildForm.tblTextBox.Paste()
    End Sub

    Private Sub CopyToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem1.Click
        frmChildForm.tblTextBox.Copy()
    End Sub

    Private Sub AverageUnitsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AverageUnitsToolStripMenuItem.Click

    End Sub
#End Region
#Region "ToolStrip"
    Private Sub SaveButton1_Click(sender As Object, e As EventArgs) Handles SaveButton1.Click
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                Dim activeForm As frmChildForm = DirectCast(Me.ActiveMdiChild, frmChildForm)

                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, activeForm.tblTextBox.Text, False)
            Catch ex As Exception
                MessageBox.Show("No File To Save Exist", "Error!", MessageBoxButtons.OK,
                           MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub NewButton1_Click(sender As Object, e As EventArgs) Handles NewButton1.Click
        Dim result As Integer = MessageBox.Show("Have You Saved Your Document?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            frmChildForm.tblTextBox.Clear()
            MessageBox.Show("New Document Created")
            Dim docform As New frmChildForm()
            docform.MdiParent = Me
            docNumberInteger = docNumberInteger + 1
            docform.Text = "New Document " & docNumberInteger
            docform.Show()
        ElseIf CBool(DialogResult.No) Then
            MessageBox.Show("Please Save Document")
        End If
    End Sub
#End Region
End Class